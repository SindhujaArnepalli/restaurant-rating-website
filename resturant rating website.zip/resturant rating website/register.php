<?php
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // Change this to your MySQL password
$dbname = "restaurant"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Use bcrypt for password hashing

    // Prepare and execute SQL statement
    $sql = "INSERT INTO users (FirstName, LastName, Email, Password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $firstName, $lastName, $email, $hashed_password);

    if ($stmt->execute()) {
        // Registration successful
        $_SESSION["email"] = $email; // Set session variable
        header("Location: index.html"); // Redirect to dashboard or any other page
        exit();
    } else {
        // Registration failed
        $error = "Registration failed. Please try again.";
    }

    // Close statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>
