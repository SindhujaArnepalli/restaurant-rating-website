<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "restaurant";

// Initialize a variable to track if the form was submitted
$formSubmitted = false;

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Set form submitted flag
    $formSubmitted = true;

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare data for insertion
    $restaurantName = $_POST["restaurantName"];
    $rating = $_POST["rating"];
    $comment = $_POST["comment"];
    
    // Insert data into the database
    $sql = "INSERT INTO ratings_table (restaurantName, rating, comment) VALUES (?, ?, ?)";
    
    // Prepare statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sis", $restaurantName, $rating, $comment); // 's' for string, 'i' for integer
    
    // Execute the statement
    if ($stmt->execute()) {
        // Success message to be displayed once
        $successMessage = "Review submitted successfully!";
    } else {
        // Error message
        echo "Error: " . $conn->error;
    }

    // Close the statement
    $stmt->close();

    // Close the connection
    $conn->close();
}
?>

<script>
    // Check if the form was submitted and display the success message
    <?php if ($formSubmitted && isset($successMessage)): ?>
        alert("<?php echo $successMessage; ?>");
        window.location.href = 'review.html'; // Reload the page immediately after clicking "OK"
    <?php endif; ?>
</script>
