<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "restaurant";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch records from the database
$sql = "SELECT restaurantName, rating, comment FROM ratings_table";
$result = $conn->query($sql);

// Display records
if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<div class='review-item'>";
        echo "<h3>" . $row["restaurantName"] . "</h3>";
        echo "<p>Rating: " . $row["rating"] . "</p>";
        echo "<p>Comment: " . $row["comment"] . "</p>";
        echo "</div>";
    }
} else {
    echo "0 results";
}

// Close the connection
$conn->close();
?>
