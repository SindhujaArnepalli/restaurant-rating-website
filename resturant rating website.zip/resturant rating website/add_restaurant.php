<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "restaurant";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare data for insertion
$restaurantName = $_POST["restaurantName"];
$restaurantAddress = $_POST["restaurantAddress"];
$restaurantPhoto = $_FILES["restaurantPhoto"]["name"]; // Assuming you're storing the file name in the database

// Example for Dish 1
$dish1Name = $_POST["dish1Name"];
$dish1Price = $_POST["dish1Price"];
$dish1Image = $_FILES["dish1Image"]["name"]; // Assuming you're storing the file name in the database

// Insert data into the database
$sql = "INSERT INTO restaurants (restaurantName, restaurantAddress, restaurantPhoto, dish1Name, dish1Price, dish1Image) 
        VALUES ('$restaurantName', '$restaurantAddress', '$restaurantPhoto', '$dish1Name', '$dish1Price', '$dish1Image')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
